document.addEventListener('DOMContentLoaded', () => {
    const obraSelector = document.getElementById('obraSelector');
    const obraTitulo = document.getElementById('obraTitulo');
    const obraDescripcion = document.getElementById('obraDescripcion');
    const obraAutores = document.getElementById('obraAutores');
    const obraValoracion = document.getElementById('obraValoracion');
    const obraDirector = document.getElementById('obraDirector');
    const obraDuracion = document.getElementById('obraDuracion');


/*
    // Genera dinámicamente los botones de opción
    obras.forEach(obra => {
        const input = document.createElement('input');
        input.type = 'radio';
        input.name = 'obraRadio';
        input.id = `opt${obra.id}`;
        input.addEventListener('change', () => mostrarDetalles(obra));

        const label = document.createElement('label');
        label.htmlFor = `opt${obra.id}`;
        label.textContent = obra.titulo;

        obraSelector.appendChild(input);
        obraSelector.appendChild(label);
    });

    // Muestra los detalles de la obra seleccionada
    function mostrarDetalles(obra) {
        obraTitulo.textContent = obra.titulo;
        obraDescripcion.textContent = obra.descripcion;
        obraAutores.textContent = obra.autores;
        obraValoracion.textContent = obra.valoracion;
        obraDirector.textContent = obra.director;
        obraDuracion.textContent = obra.duracion;

    }
});
*/

let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.header__navbar');

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navbar.classList.toggle('open');
}

const nav = document.querySelector('.header__navbar');
window.addEventListener('scroll', function () {
    navbar.classList.toggle('active', window.scrollY > 0)
})
})
function recoverFunction() { // recupera el slug
    const queryString = window.location.search
    console.log(queryString)
    const urlParams = new URLSearchParams(queryString)
    return urlParams.get('titulo')
}

const tituloObras = recoverFunction()

async function writeData(name) {
    const options = { method: 'GET' }
    const response = await fetch('http://localhost:3000/api/datosobras/' + name, options)
    return response.json()
}

async function fillFunction(data) {

 

    const nameObra = document.querySelector('#obraTitulo')
    nameObra.innerHTML = data.obra.titulo

    const descriptionObra = document.querySelector('#obraDescripcion')
    descriptionObra.innerHTML = data.obra.descripcion

    const autoresObra = document.querySelector('#obraAutores')
    autoresObra.innerHTML = data.obra.autores

    const valoracionObra = document.querySelector('#obraValoracion')
    valoracionObra.innerHTML = data.obra.valoracion

    const directorObras = document.querySelector('#obraDirector')
    directorObras.innerHTML = data.obra.director

    const duracionObra = document.querySelector('#obraDuracion')
    duracionObra.innerHTML = data.obra.duracion
}

async function fetchData() {
    const data = await writeData(tituloObras)
    fillFunction(data)
}

fetchData()
