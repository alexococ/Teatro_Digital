document.addEventListener('DOMContentLoaded', () => {
    const seatContainer = document.getElementById('seatContainer');
    const countSpan = document.getElementById('count');
    const totalSpan = document.getElementById('total');
    const reserveButton = document.getElementById('reserve-button');

    let selectedSeats = [];

    const rows = 8; // Número de filas
    const seatsPerRow = 12; // Número de asientos por fila
    const seatsOccupied = [6, 7, 8, 15, 16, 17, 24, 25, 26]; // Asientos ocupados (puedes personalizar esta lista)

    function toggleSeatStatus(seatElement, row, seat) {
        seatElement.classList.toggle('selected');

        const seatIndex = selectedSeats.findIndex((s) => s.row === row && s.seat === seat);

        if (seatIndex !== -1) {
            // Si el asiento ya está seleccionado, quitarlo de la lista
            selectedSeats.splice(seatIndex, 1);
        } else {
            // Si el asiento no está seleccionado, agregarlo a la lista
            selectedSeats.push({ row, seat });
        }

        updateSelectedSeats();
    }

    function updateSelectedSeats() {
        const selectedCount = selectedSeats.length;
        const totalPrice = selectedCount * 10; // Precio por asiento

        countSpan.innerText = selectedCount;
        totalSpan.innerText = `$${totalPrice}`;

        reserveButton.addEventListener('click', () => {
            // Realizar la solicitud POST/PUT a la API para marcar los asientos
            $.ajax({
                url: 'http://localhost:3000/api/reservar-asientos',
                method: 'POST', // Puedes usar 'PUT' si es más apropiado
                contentType: 'application/json',
                data: JSON.stringify({ seats: selectedSeats }),
                success: function (response) {
                    console.log('Asientos marcados con éxito:', response.reservedSeats);
                    // Puedes redirigir a la página de pago u otra acción después de marcar los asientos
                },
                error: function (error) {
                    console.error('Error al marcar los asientos:', error);
                }
            });
        });
    }

    for (let i = 0; i < rows; i++) {
        const rowElement = document.createElement('div');
        rowElement.classList.add('row');

        for (let j = 0; j < seatsPerRow; j++) {
            const seatElement = document.createElement('div');
            seatElement.classList.add('seat');

            // Verificar si el asiento está ocupado
            const isOccupied = seatsOccupied.includes(i * seatsPerRow + j + 1);
            if (isOccupied) {
                seatElement.classList.add('occupied');
            } else {
                // Manejar clic en los asientos
                seatElement.addEventListener('click', () => {
                    toggleSeatStatus(seatElement, i, j + 1);
                });
            }

            rowElement.appendChild(seatElement);
        }

        seatContainer.appendChild(rowElement);
    }
});









// TITULO DE LA OBRA OBTENIDA DE DETALLES.
document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const tituloObra = decodeURIComponent(urlParams.get('obra'));
    if (tituloObra) {
        document.getElementById('obraTitulo').textContent = tituloObra;
    }
});



document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const tituloObra = decodeURIComponent(urlParams.get('obra'));

    const totalPagar = document.getElementById('totalPagar').textContent; 

    const enlaceReservar = document.getElementById('enlaceReservar');
    enlaceReservar.href = `pagar.html?obra=${encodeURIComponent(tituloObra)}&total=${encodeURIComponent(totalPagar)}`;
});
