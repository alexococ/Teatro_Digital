<script setup>
import Header from './components/Header.vue'
import Carrusel from './components/Carrusel.vue'
import ObrasHome from './components/ObrasHome.vue'
import Asientos from './components/Asientos.vue'
import Footer from './components/Footer.vue'


const obras = [
  { title: 'Wicked', id: 1, image:  'https://m.media-amazon.com/images/M/MV5BNjczYjBhMTctYTA3Yy00NTgyLWFkZWQtZjQwYTRkMDc1YTc1XkEyXkFqcGdeQXVyNTk5NTQzNDI@._V1_.jpg'},
  { title: 'La divina comedia', id: 2, image: 'https://m.media-amazon.com/images/I/71WJbXGxPdL._AC_UF1000,1000_QL80_.jpg' },
  { title: 'la vida es sueño', id: 3, image:   'https://www.elejandria.com/covers/La_vida_es_sueno-Calderon_de_la_Barca_Pedro-md.png'}
]

</script>



<!-- COMPONENTES DE LA HOMEPAGE -->
<template>


  <!-- CABECERA -->
  <Header></Header>


  <!-- CARRUSEL -->
  <Carrusel></Carrusel>


  <h1 class="obras__title">Nuevas obras</h1>
  <!-- OBRAS -->
  <div class="container-obras">
    <ObrasHome v-for="obra in obras" :key="obra.id" :title="obra.title" :image="obra.image" />
  </div>


  <!-- ASIENTOS -->
  <Asientos></Asientos>


  <!-- FOOTER -->
  <Footer></Footer>
</template>


