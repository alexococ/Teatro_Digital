<script setup>
import Header from './components/Header.vue'
import Carrusel from './components/Carrusel.vue'
import ObrasHome from './components/ObrasHome.vue'
import Asientos from './components/Asientos.vue'
import Footer from './components/Footer.vue'

</script>



<!-- COMPONENTES DE LA HOMEPAGE -->
<template>


  <!-- CABECERA -->
  <Header></Header>


  <!-- CARRUSEL -->
  <Carrusel></Carrusel>


  <!-- OBRAS -->
  <ObrasHome></ObrasHome>


  <!-- ASIENTOS -->
  <Asientos></Asientos>


  <!-- FOOTER -->
  <Footer></Footer>


</template>


