
<script setup lang = "ts">
defineProps<{
    title?: string
    image?: string
}>()
</script>



<template>
    <!-- Obras -->
    <div class="obra">
        <div class="container-img">
            <img :src="image" :alt="title" class="img-item" />
        </div>
        <div class="content-card-obra">
            <h3 class="content-card-obra__title">{{ title }}</h3>
            <a href="menu.html"><button class="obras-button content-card-obra__button">Ver mas</button></a>
        </div>
    </div>
    <br><br><br>
</template>





<style>
.container-obras {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(10rem, 1fr));
    width: 100%;
    margin-bottom: 70px;
}

.obras__title {
    justify-content: center;
    align-items: center;
    text-align: center;
    font-size: 50px;
    color: #000;
}

.obra {
    text-align: center;
    width: 197%;
    background-color: var(--text-color);
    padding: 2rem 3rem;
    border-radius: 0.5rem;
    box-shadow: var(--box-shadow);
}

.container-img {
    position: relative;
}

.container-img img {
    width: 100%;
}

.content-card-obra {
    display: grid;
    justify-items: center;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: repeat(3, min-content);
    row-gap: 1rem;
}

.content-card-obra__title {
    grid-row: 1/1;
    grid-column: 1/-1;
    font-weight: 400;
    font-size: 1.6rem;
}


.obras-button,
.content-card-obra__button {
    background-color: var(--dark-color);
    border: none;
    border-radius: 30px;
    padding: 14px 35px;
    color: white;
    font-size: 20px;
    font-weight: 600;
    cursor: pointer;
}

.obras-button:hover,
.content-card-obra__button:hover {
    background-color: var(--btn-color);
    color: #ffffff;
    box-shadow: var(--box-shadow);
}

.content-card-obra__button {
    width: 300%;
}

</style>