
<script setup lang = "ts">
defineProps(['title'])
</script>



<template>
    <section class="container obras">

        <h1 class="obras__title">Nuevas obras</h1>

        <div class="container-obras">
            
            <!-- Obra 1 -->
            <div class="obra">
                <div class="container-img">
                    <img src="../assets/img/ObraHome1.jpg"
                        alt="OBRA UNO" class="img-item" />
                </div>
                <div class="content-card-obra">
                    <h3 class="content-card-obra__title">{{title}}</h3>
                    <a href="menu.html"><button class="obras-button content-card-obra__button">Ver mas</button></a>
                </div>
            </div>

            <!-- Obra 2 -->
            <div class="obra">
                <div class="container-img">
                    <img src="../assets/img/ObraHome2.jpg" alt="OBRA DOS"
                        class="img-item" />
                </div>
                <div class="content-card-obra">
                    <h3 class="content-card-obra__title">{{title}}</h3>
                    <a href="menu.html"><button class="obras-button content-card-obra__button">Ver mas</button></a>
                </div>
            </div>

            <!-- Obra 3 -->
            <div class="obra">
                <div class="container-img">
                    <img src="../assets/img/ObraHome3.png"
                        alt="OBRA TRES" class="img-item" />
                </div>
                <div class="content-card-obra">
                    <h3 class="content-card-obra__title">{{title}}</h3>
                    <a href="menu.html"><button class="obras-button content-card-obra__button">Ver mas</button></a>
                </div>
            </div>
        </div>
    </section>

    <br><br><br>
</template>





<style>
.container-obras {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(20rem, 1fr));
    gap: 3rem;
    width: 100%;
}

.obras__title {
    justify-content: center;
    align-items: center;
    text-align: center;
    font-size: 50px;
    color: #000;
    margin-bottom: 55px;
}

.obra {
    background-color: var(--text-color);
    padding: 2rem 3rem;
    border-radius: 0.5rem;
    box-shadow: var(--box-shadow);
}

.container-img {
    position: relative;
}

.container-img img {
    width: 100%;
}

.content-card-obra {
    display: grid;
    justify-items: center;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: repeat(3, min-content);
    row-gap: 1rem;
}

.content-card-obra__title {
    grid-row: 1/1;
    grid-column: 1/-1;
    font-weight: 400;
    font-size: 1.6rem;
}


.obras-button,
.content-card-obra__button {
    background-color: var(--dark-color);
    border: none;
    border-radius: 30px;
    padding: 14px 35px;
    color: white;
    font-size: 20px;
    font-weight: 600;
    cursor: pointer;
    grid-row: 1/1;
    grid-column: 1/-1;
}

.obras-button:hover,
.content-card-obra__button:hover {
    background-color: var(--btn-color);
    color: #ffffff;
    box-shadow: var(--box-shadow);
}

.content-card-obra__button {
    grid-row: 1/2;
    grid-column: 1/-1;
    justify-self: center;
}


</style>