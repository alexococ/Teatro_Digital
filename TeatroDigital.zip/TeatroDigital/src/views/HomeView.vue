<script setup lang = "ts">
import ObrasHome from '../components/ObrasHome.vue'

const obras = [{title: 'Wicked', id: 1}, {title: 'La divina comedia', id: 2}, {title: 'la vida es sueño', id: 3}]
</script>

<template>
    <main>
        <Header/>
        <Card
            v-for="obra in obras"
            :key="obra.id"
            :title="obra.title"
        />
    </main>
</template>

