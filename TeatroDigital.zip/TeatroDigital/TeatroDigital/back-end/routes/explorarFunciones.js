const express = require('express');
const router = express.Router();

router.get('/explorarFunciones', (req, res) => {
    // Manejar la lógica de la ruta aquí
});

module.exports = router;
