// Define las funciones de controlador aquí
module.exports = {
    listarFunciones: (req, res) => {
      // Lógica para listar funciones
    },
    obtenerFuncion: (req, res) => {
      // Lógica para obtener una función específica
    },
    // ... otras funciones de controlador ...
  };
  