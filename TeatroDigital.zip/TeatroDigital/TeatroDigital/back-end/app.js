const express = require('express');
const app = express();
const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
    console.log(`Servidor iniciado en el puerto ${PORT}`);
});



// IMPORTAR LA RUTA explorarFunciones
const explorarFuncionesRouter = require('./routes/explorarFunciones');
app.use('/', explorarFuncionesRouter);
