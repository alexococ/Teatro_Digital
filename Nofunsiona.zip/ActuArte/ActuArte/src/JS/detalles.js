/* CODIGO PARA DETALLES DE UNA OBRA */

document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const obraId = urlParams.get('id'); // Obtener el ID de la URL

    if (obraId) {
        // Realizar una solicitud a la API para obtener los detalles de la obra
        fetch(`http://localhost:3000/api/obras/${obraId}`)
            .then(response => response.json())
            .then(data => {
                // Actualizar los elementos HTML con los detalles de la obra
                document.getElementById('obraTitulo').textContent = data.titulo || 'Título no disponible';
                document.getElementById('obraDescripcion').textContent = data.descripcion || 'Descripción no disponible';
                // Agregar aquí actualizaciones para otros elementos como obraAutores, obraValoracion, etc.
            })
            .catch(error => {
                console.error('Error al obtener los detalles de la obra:', error);
                // Manejar adecuadamente el error en la interfaz de usuario
            });
    } else {
        // Manejar el caso en que no se proporciona un ID en la URL
        console.error('No se proporcionó un ID de obra en la URL');
        // Actualizar la interfaz de usuario para reflejar la falta de detalles
    }
});

