

// JAVASCRIPT DEL MENU DE LAS OBRAS

/* 
    * MENU DESPLEGABLE DEL HEADER

    * METODO DE FILTRADO DE OBRAS

    * FLECHA DE DESPLAZAMIENTO A LAS OBRAS

    * CARGAR LAS OBRAS INICIALES
*/




/* ---------------------------------------------- MENU DESPLEGABLE ---------------------------------------------- */
let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.header__navbar');

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navbar.classList.toggle('open');
}

const nav = document.querySelector('.header__navbar');
window.addEventListener('scroll', function () {
    navbar.classList.toggle('active', window.scrollY > 0)
})






/* ---------------------------------------------- FILTRADO DE LAS OBRAS ---------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
    const obrasContainer = document.getElementById('obras-container');
    const ultimasBtn = document.getElementById('ultimas-sesiones');
    const aclamadasBtn = document.getElementById('aclamadas');
    const recientesBtn = document.getElementById('recientes');

    const todasObras = [
        
    ];

    const ultimasObras = [
        { titulo: 'Los Miserables', imagen: 'https://m.media-amazon.com/images/I/517Cb2FS4qL.jpg' },
        { titulo: 'Cats', imagen: 'https://upload.wikimedia.org/wikipedia/en/3/30/Cats_1998_DVD_Cover.jpg' },
        { titulo: 'Casa de Muñecas', imagen: 'https://images.cdn3.buscalibre.com/fit-in/360x360/ef/99/ef9995dc7f336bc670c2775b7316b143.jpg' },
        { titulo: 'El enfermo imaginario', imagen: 'https://www.tarambana.net/upload/espectaculos/foto_poster-1296.jpg?id=117364' },
        { titulo: 'El alcalde de Zalamea', imagen: 'https://m.media-amazon.com/images/I/51fM26seM-L.jpg' },
    ];

    const aclamadasObras = [
        { titulo: 'Romeo y Julieta', imagen: 'https://almeriaciudad.es/cultura/wp-content/archivos/sites/21/2022/02/IMG_2391-1.jpeg' },
        { titulo: 'La Celestina', imagen: 'https://www.cervantesvirtual.com/s3/BVMC_OBRAS/ffa/c66/288/2b1/11d/fac/c70/021/85c/e60/64/mimes/imagenes/ffac6628-82b1-11df-acc7-002185ce6064_2.jpg' },
        { titulo: 'Hamlet', imagen: 'https://cdn.kobo.com/book-images/5fc4252b-1c4f-40ef-9975-22982c94f12c/1200/1200/False/hamlet-prince-of-denmark-23.jpg' },
        { titulo: 'El Fantasma de la Ópera', imagen: 'https://teatroaranjuez.es/wp-content/uploads/2023/10/el-fantasma-de-la-opera-330x467-1.jpg' },
        { titulo: 'Sueño de una Noche de Verano', imagen: 'https://image.isu.pub/190709204809-9c82f7fce8bb840f1ff3b5631eef637f/jpg/page_1.jpg' },
        { titulo: 'Don Juan Tenorio', imagen: 'https://m.media-amazon.com/images/I/61Er0I3cJaL._AC_UF1000,1000_QL80_.jpg' },
        { titulo: 'Fuenteovejuna', imagen: 'https://m.media-amazon.com/images/I/418RabpIZVS.jpg' },
    ];

    const recientesObras = [
        { titulo: 'La Casa de Bernarda Alba', imagen: 'https://chglenguayliteratura.files.wordpress.com/2020/01/aaaa.jpg' },
        { titulo: 'Wicked', imagen: 'https://m.media-amazon.com/images/M/MV5BNjczYjBhMTctYTA3Yy00NTgyLWFkZWQtZjQwYTRkMDc1YTc1XkEyXkFqcGdeQXVyNTk5NTQzNDI@._V1_.jpg' },
        { titulo: 'La Divina Comedia', imagen: 'https://m.media-amazon.com/images/I/71WJbXGxPdL._AC_UF1000,1000_QL80_.jpg' },
        { titulo: 'La Vida es Sueño', imagen: 'https://www.elejandria.com/covers/La_vida_es_sueno-Calderon_de_la_Barca_Pedro-md.png' },
    ];

    // Función para actualizar la lista de obras en el contenedor
    function actualizarObras(listaDeObras) {
        // Limpiar el contenedor
        obrasContainer.innerHTML = '';

        // Agregar las obras al contenedor
        listaDeObras.forEach(obra => {
            const cardProduct = document.createElement('div');
            cardProduct.classList.add('card-product');

            const containerImg = document.createElement('div');
            containerImg.classList.add('container-img');

            const imgItem = document.createElement('img');
            imgItem.src = obra.imagen;
            imgItem.alt = obra.titulo;
            imgItem.classList.add('img-item');

            containerImg.appendChild(imgItem);

            const contentCardProduct = document.createElement('div');
            contentCardProduct.classList.add('content-card-product');

            const tituloItem = document.createElement('h3');
            tituloItem.classList.add('titulo-item');
            tituloItem.textContent = obra.titulo;

            // Cambios aquí: Crear un enlace <a> con el parámetro de consulta
            const detallesLink = document.createElement('a');
        detallesLink.href = `detalles.html?id=${obra.id}`; // Usar el ID de la obra

            const detallesButton = document.createElement('button');
            detallesButton.classList.add('obras-button');
            detallesButton.textContent = 'Detalles';

            detallesLink.appendChild(detallesButton); // Agregar el botón al enlace
            contentCardProduct.appendChild(tituloItem);
            contentCardProduct.appendChild(detallesLink); // Agregar el enlace al contenedor de la tarjeta

            cardProduct.appendChild(containerImg);
            cardProduct.appendChild(contentCardProduct);

            obrasContainer.appendChild(cardProduct);
        });
    }

    // Llamada inicial para mostrar todas las obras al cargar la página
    actualizarObras(todasObras);

    // Manejar clic en el botón "ultiimasObras"
    ultimasBtn.addEventListener('click', () => {
        actualizarObras(ultimasObras);
    });

    // Manejar clic en el botón "Mas aclamadas"
    aclamadasBtn.addEventListener('click', () => {
        actualizarObras(aclamadasObras);
    });

    // Manejar clic en el botón "Recientes"
    recientesBtn.addEventListener('click', () => {
        actualizarObras(recientesObras);
    });
});





/* ---------------------------------------------- FLECHA DE DESPLAZAMIENTO A LAS OBRAS DE TEATRO ---------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
    const arrow = document.getElementById('arrow');
    const arrowFinal = document.getElementById('arrow-final');

    // Manejar clic en la flecha
    arrow.addEventListener('click', () => {
        // Utilizar el método `scrollIntoView` para desplazamiento suave
        arrowFinal.scrollIntoView({ behavior: 'smooth' });
    });
});








/* ---------------------------------------------- CARGAR LAS OBRAS DE TEATRO PINTANDO EN EL HTML ---------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
    const obrasContainer = document.getElementById('obras-container');

    // Hacer una solicitud a la API REST para obtener datos
    fetch('http://localhost:3000/api/obras')
        .then(response => response.json())
        .then(data => {
            // Iterar sobre los datos y crear tarjetas de obra
            data.forEach(obra => {
                const cardProduct = document.createElement('div');
                cardProduct.classList.add('card-product');

                const containerImg = document.createElement('div');
                containerImg.classList.add('container-img');

                const imgItem = document.createElement('img');
                imgItem.src = obra.imagen;
                imgItem.alt = obra.titulo;
                imgItem.classList.add('img-item');

                containerImg.appendChild(imgItem);

                const contentCardProduct = document.createElement('div');
                contentCardProduct.classList.add('content-card-product');

                const tituloItem = document.createElement('h3');
                tituloItem.classList.add('titulo-item');
                tituloItem.textContent = obra.titulo;

                const detallesButton = document.createElement('button');
                detallesButton.classList.add('obras-button');
                detallesButton.textContent = 'Detalles';

                contentCardProduct.appendChild(tituloItem);
                contentCardProduct.appendChild(detallesButton);

                cardProduct.appendChild(containerImg);
                cardProduct.appendChild(contentCardProduct);

                obrasContainer.appendChild(cardProduct);
            });
        })
        .catch(error => console.error('Error al obtener datos de la API:', error));
});








