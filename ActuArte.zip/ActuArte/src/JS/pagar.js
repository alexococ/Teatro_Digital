let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.header__navbar');

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navbar.classList.toggle('open');
}

const nav = document.querySelector('.header__navbar');
window.addEventListener('scroll', function () {
    navbar.classList.toggle('active', window.scrollY > 0)
});





document.addEventListener('DOMContentLoaded', () => {
    // Obtener la información de la reserva desde localStorage
    const reservationData = JSON.parse(localStorage.getItem('reservation'));

    if (reservationData) {
        // Mostrar el nombre de la obra
        const obraNameElement = document.querySelector('.title.o-5');
        obraNameElement.textContent = reservationData.obraName || '';

        // Mostrar el monto total de la reserva
        const summaElement = document.querySelector('.summa');
        summaElement.textContent = `$${reservationData.totalPrice || 0}`;

        // Lógica adicional según tus necesidades
        // ...

        // Puedes limpiar la información de la reserva de localStorage después de mostrarla
        // localStorage.removeItem('reservation');
    } else {
        // Si no hay información de reserva, redirigir a la página de inicio o hacer algo más
        window.location.href = './index.html';
    }
});
