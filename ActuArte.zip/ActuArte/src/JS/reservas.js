document.addEventListener('DOMContentLoaded', () => {
    const obraDropdown = document.getElementById('obras');
    const seats = document.querySelectorAll('.row .seat');
    const countSpan = document.getElementById('count');
    const totalSpan = document.getElementById('total');
    const reserveButton = document.getElementById('reserve-button');

    let obraValue = obraDropdown.value;
    let obraName = obraDropdown.options[obraDropdown.selectedIndex].text; // Obtener el nombre de la obra
    let selectedSeats = [];

    // Configuraciones de asientos ocupados para cada obra
    const configuracionesAsientos = {
        1: [6, 7, 8, 11, 12],
        2: [4, 5, 10, 11],
        3: [2, 5, 8],
        4: [1, 2, 3, 10, 11, 12],
        5: [4, 5, 6, 9, 10],
        6: [1, 2, 3, 8, 9, 12],
        7: [1, 2, 3, 10, 11, 12],
        8: [4, 5, 6, 9, 10],
        9: [1, 2, 3, 8, 9, 12],
        10: [4, 5, 6, 9, 10],
        11: [1, 2, 3, 10, 11, 12],
        12: [4, 5, 6, 9, 10],
        13: [1, 2, 3, 8, 9, 12],
        14: [4, 5, 6, 9, 10],
        15: [1, 2, 3, 10, 11, 12],
        16: [4, 5, 6, 9, 10],
    };

    // Actualizar asientos ocupados al cambiar la obra
    obraDropdown.addEventListener('change', () => {
        obraValue = obraDropdown.value;
        obraName = obraDropdown.options[obraDropdown.selectedIndex].text; // Actualizar el nombre de la obra
        actualizarAsientosOcupados();
    });

    // Manejar clic en un asiento
    seats.forEach((seat, index) => {
        seat.addEventListener('click', () => {
            if (!seat.classList.contains('occupied')) {
                seat.classList.toggle('selected');

                if (selectedSeats.includes(index)) {
                    // Si ya está seleccionado, quitarlo de los asientos seleccionados
                    selectedSeats = selectedSeats.filter(seatIndex => seatIndex !== index);
                } else {
                    // Si no está seleccionado, agregarlo a los asientos seleccionados
                    selectedSeats.push(index);
                }

                actualizarContadorPrecio();
            }
        });
    });

    // Función para actualizar los asientos ocupados según la obra seleccionada
    function actualizarAsientosOcupados() {
        seats.forEach((seat, index) => {
            seat.classList.remove('occupied');

            if (configuracionesAsientos[obraValue] && configuracionesAsientos[obraValue].includes(index)) {
                seat.classList.add('occupied');
            }
        });

        // También desmarcar los asientos seleccionados si ya no están disponibles
        selectedSeats = selectedSeats.filter(seatIndex => !configuracionesAsientos[obraValue].includes(seatIndex));

        actualizarContadorPrecio();
    }

    // Función para actualizar el contador y precio
    function actualizarContadorPrecio() {
        const selectedSeatsCount = selectedSeats.length;
        const selectedSeatsPrice = selectedSeatsCount * 10; // Precio por asiento

        countSpan.textContent = selectedSeatsCount;
        totalSpan.textContent = `$${selectedSeatsPrice}`;
    }

    // Inicializar asientos ocupados
    actualizarAsientosOcupados();

    // Agregar evento al botón de reservar
    reserveButton.addEventListener('click', () => {
        // Guardar la información en localStorage, incluido el monto total
        const reservationData = {
            obra: obraValue,
            obraName: obraName, // Incluir el nombre de la obra
            seats: selectedSeats,
            totalPrice: selectedSeats.length * 10
        };
        localStorage.setItem('reservation', JSON.stringify(reservationData));

        // Redirigir a la página de pago
        window.location.href = './pagar.html';
    });
});
