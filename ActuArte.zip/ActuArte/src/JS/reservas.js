document.addEventListener('DOMContentLoaded', () => {
    const seatContainer = document.getElementById('seatContainer');
    const countSpan = document.getElementById('count');
    const totalSpan = document.getElementById('total');
    const reserveButton = document.getElementById('reserve-button');

    let selectedSeats = [];

    const rows = 8; // Número de filas
    const seatsPerRow = 12; // Número de asientos por fila
    const seatsOccupied = [6, 7, 8, 15, 16, 17, 24, 25, 26]; // Asientos ocupados (puedes personalizar esta lista) 

    for (let i = 0; i < rows; i++) {
        const rowElement = document.createElement('div');
        rowElement.classList.add('row');

        for (let j = 0; j < seatsPerRow; j++) {
            const seatElement = document.createElement('div');
            seatElement.classList.add('seat');

            // Verificar si el asiento está ocupado
            const isOccupied = seatsOccupied.includes(i * seatsPerRow + j + 1);
            if (isOccupied) {
                seatElement.classList.add('occupied');
            } else {
                // Manejar clic en los asientos
                seatElement.addEventListener('click', () => {
                    toggleSeatStatus(seatElement, i, j + 1);
                });
            }

            rowElement.appendChild(seatElement);
        }

        seatContainer.appendChild(rowElement);
    }


    // Ejemplo de función para seleccionar asientos
    function toggleSeatStatus(seat, row, number) {
        if (!seat.classList.contains('occupied')) {
            seat.classList.toggle('selected');
            updateSelectedCount();
            seat.style.backgroundColor = seat.classList.contains('selected') ? '#f1d791' : '';
        }
    }

    // Función para actualizar el conteo y precio total
    function updateSelectedCount() {
        selectedSeats = document.querySelectorAll('.row .seat.selected');
        const selectedSeatsCount = selectedSeats.length;
        countSpan.innerText = selectedSeatsCount;
        totalSpan.innerText = selectedSeatsCount * 10; // Asumiendo un precio fijo por asiento
    }

    reserveButton.addEventListener('click', () => {
        const seatsData = [...selectedSeats].map(seat => {
            const seatIndex = seat.getAttribute('data-seat-index');
            return seatIndex;
        });

        fetch('/api/reservar-asientos', {
            method: 'POST', // Cambia a 'PUT' si es necesario
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ seats: seatsData })
        })
            .then(response => response.json())
            .then(data => {
                selectedSeats.forEach(seat => {
                    seat.classList.remove('selected');
                    seat.classList.add('occupied');
                    seat.style.backgroundColor = '#5e0a0f';
                });
                updateSelectedCount(); // Actualizar conteo a 0

                // Mostrar mensaje de confirmación
                alert(`Has comprado esta obra: ${document.getElementById('obraTitulo').innerText}`);
            })
            .catch(error => console.error('Error:', error));
    });


    fetch('/api/estado-asientos')
        .then(response => response.json())
        .then(data => {
            // Aquí asumimos que 'data' es un array con los índices de los asientos ocupados
            data.forEach(seatIndex => {
                const seat = document.querySelector(`[data-seat-index='${seatIndex}']`);
                if (seat) {
                    seat.classList.add('occupied');
                    seat.style.backgroundColor = '#5e0a0f'; // Color para asientos ocupados
                }
            });
        })
        .catch(error => console.error('Error al cargar el estado de los asientos:', error));


});










// TITULO DE LA OBRA OBTENIDA DE DETALLES.
document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const tituloObra = decodeURIComponent(urlParams.get('obra'));
    if (tituloObra) {
        document.getElementById('obraTitulo').textContent = tituloObra;
    }
});



document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const tituloObra = decodeURIComponent(urlParams.get('obra'));

    const totalPagar = document.getElementById('totalPagar').textContent;

    const enlaceReservar = document.getElementById('enlaceReservar');
    enlaceReservar.href = `pagar.html?obra=${encodeURIComponent(tituloObra)}&total=${encodeURIComponent(totalPagar)}`;
});
