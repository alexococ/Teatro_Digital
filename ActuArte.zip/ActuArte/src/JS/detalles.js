document.addEventListener('DOMContentLoaded', () => {
    const obraSelector = document.getElementById('obraSelector');
    const obraTitulo = document.getElementById('obraTitulo');
    const obraDescripcion = document.getElementById('obraDescripcion');

    const obras = [

        {
            id: 1, titulo: 'Romeo y Julieta',
            descripcion: 'La excelente y lamentable tragedia de Romeo y Julieta cuenta la historia de dos jóvenes enamorados, Romeo y Julieta, quienes pertenecen a dos familias poderosas y enemigas de la ciudad renacentista de Verona, Italia: los Montesco y los Capuleto. Los protagonistas se conocen en un baile familiar de los Capuleto, en el que Romeo y sus amigos se cuelan, a pesar del peligro que corren y de que el rey de la ciudad ha decretado una frágil tregua entre las familias. Y tan pronto como bailan, Romeo y Julieta quedan perdidamente enamorados el uno del otro.'
        },

        {
            id: 2, titulo: 'La Casa de Bernarda Alba',
            descripcion: 'Tras la muerte de su segundo esposo, Bernarda Alba se recluye e impone un luto riguroso y asfixiante por ocho años, prohibiendo a sus cinco hijas a que vayan a la fiesta. Cuando Angustias, la primogénita y la única hija del primer marido, hereda una fortuna, atrae a un pretendiente, Pepe el Romano.'
        },

        {
            id: 3, titulo: 'La Celestina',
            descripcion: 'La loca pasión por Melibea, hija de un rico mercader, lleva al joven Calisto a romper todas las barreras y a aliarse con una vieja alcahueta. Desde el momento en que entra en escena, Celestina avasalla toda la obra hasta convertirse en un personaje literario de fama universal.'
        },

        {
            id: 4, titulo: 'La Vida es Sueño',
            descripcion: 'El rey Basilio va a tener un hijo. Pero un adivino le dice que ese nacimiento traerá el desastre al reino. En efecto, nada más nacer la madre muere, y el rey, asustado encierra a su hijo en una torre escondida entre montañas de forma que nadie sepa donde está. Solo Clotaldo, su ayo, conoce su paradero.'
        },

        {
            id: 5, titulo: 'Hamlet',
            descripcion: 'La tragedia de Hamlet, Príncipe de Dinamarca cuenta la historia del joven heredero al trono danés, cuyo padre muerto se le aparece como un fantasma en las murallas del castillo, para invocar su venganza, pues su muerte no fue natural sino que fue envenenado por su propia esposa Gertrudis, madre de Hamlet, y su hermano y actual rey, Claudio.'
        },

        {
            id: 6, titulo: 'El Fantasma de la Ópera',
            descripcion: 'Misterio y amor en las catacumbas de París. En los sótanos de la Ópera de París se esconde un misterioso personaje que oculta su rostro desfigurado. Este ser acecha por los camerinos y vigila a Christine, una inocente muchacha con gran talento de la que se ha enamorado. A través de un tenebroso y cruel personaje, Erik, atormentado por la deformidad de su rostro y su pasión por la belleza, y de los recovecos de un edificio, la Ópera de París, Leroux nos introduce en el mundo del otro lado del telón.'
        },

        {
            id: 7, titulo: 'Sueño de una Noche de Verano',
            descripcion: 'Narra los hechos que suceden durante el casamiento de Teseo, duque de Atenas, con Hipólita, reina de las amazonas. Incluye las aventuras de cuatro amantes atenienses y un grupo de seis actores aficionados que son controlados por las hadas que habitan en el bosque donde la mayor parte de la obra tiene lugar.'
        },

        {
            id: 8, titulo: 'Don Juan Tenorio',
            descripcion: 'Don Juan Tenorio es el personaje más célebre del teatro español. La historia de este burlador de mujeres comienza en los días de Carnaval y acaba en el Día de Difuntos. Don Juan es un seductor que se mofa de todos los valores sociales establecidos. Pero su vida cambiará al conocer a doña Inés. Gracias a su amor, el alma de don Juan se salvará de las llamas del infierno.'
        },

        {
            id: 9, titulo: 'Fuenteovejuna',
            descripcion: 'El pueblo de Fuente Ovejuna, ya está harto de la crueldad de su señor, que no hace más que fastidiarlos, ya sea reclutando jóvenes para sus guerras, o deshonrando a sus mujeres, y esta es la gota que colma el vaso de su paciencia, así que deciden intervenir y matar al Comendador.'
        },

        {
            id: 10, titulo: 'La Divina Comedia',
            descripcion: 'Es una obra humana que refleja el peregrinaje del ser humano en busca de “la Luz”, es el descubrimiento del hombre hacia Dios, con la ayuda de la razón (Virgilio) y de la fe (Beatriz). El poema es una epopeya religiosa que narra con realismo un viaje, es un canto a la humanidad.'
        },

        {
            id: 11, titulo: 'El enfermo imaginario',
            descripcion: 'Argán se cree muy enfermo y no puede vivir sin estar rodeado de médicos. Para conseguir tener uno en su familia que le haga ahorrar la ingente cantidad de dinero que destina a sus curas, medicamentos y potingues, no duda en concertar un matrimonio de conveniencia entre su hija Angélica con el hijo del doctor Diafoirus.'
        },

        {
            id: 12, titulo: 'Cats',
            descripcion: 'Esta obra musical es una de las más célebres de Broadway. Fue creada por el legendario Andrew Lloyd Weber, quien a su vez se basó en los poemas de T. S. Eliot, «El libro de los gatos habilidosos del viejo Possum». Relata la historia de los Jellicle Cats, un grupo de gatos callejeros que poco a poco se va presentando ante el público, en medio de impresionantes números musicales.'
        },

        {
            id: 13, titulo: 'Wicked',
            descripcion: 'Narra la historia de Elphaba, una niña nacida de color verde y cómo se convierte en la Malvada Bruja del Oeste, pasando por los sucesos que experimenta desde su nacimiento, infancia y juventud en la Universidad de Shiz hasta llegar a la edad adulta, momento de la llegada de Dorothy a la tierra de Oz.'
        },

        {
            id: 14, titulo: 'Los Miserables',
            descripcion: 'Es la historia de Jean Valjean, un convicto que estuvo injustamente encarcelado por 19 años por haberse robado una rebanada de pan. Al ser liberado de su injusta condena, Valjean trata de escapar de su pasado, lleno de maldad y depravación, para vivir una vida digna y honesta.'
        },

        {
            id: 15, titulo: 'Casa de Muñecas',
            descripcion: 'En Casa de muñecas Ibsen aborda el problema de la situación de la mujer de la pequeña burguesía en la sociedad de su tiempo. Nora, la protagonista, es el retrato de las mujeres de su clase y puede ofrecer un retrato con mucha actualidad para las mujeres inmersas en la vorágine del mundo contemporáneo.'
        },

        {
            id: 16, titulo: 'El alcalde de Zalamea',
            descripcion: 'En el alcalde de Zalamea, se cuenta la venganza del Alcalde Pedro Crespo, que da muerte a don Álvaro, el arrogante capitán que ha secuestrado a su hija. Esta reacción no se percibe como el resultado de aplicar un código rígido y bárbaro, sino como una reacción justa que será aprobada por el rey.'
        },
    ];

    // Genera dinámicamente los botones de opción
    obras.forEach(obra => {
        const input = document.createElement('input');
        input.type = 'radio';
        input.name = 'obraRadio';
        input.id = `opt${obra.id}`;
        input.addEventListener('change', () => mostrarDetalles(obra));

        const label = document.createElement('label');
        label.htmlFor = `opt${obra.id}`;
        label.textContent = obra.titulo;

        obraSelector.appendChild(input);
        obraSelector.appendChild(label);
    });

    // Muestra los detalles de la obra seleccionada
    function mostrarDetalles(obra) {
        obraTitulo.textContent = obra.titulo;
        obraDescripcion.textContent = obra.descripcion;
        // Puedes agregar más lógica para cargar otros detalles según sea necesario
    }
});
