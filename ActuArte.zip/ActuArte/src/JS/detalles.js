
// MENU DESPLEGABLE DEL HEADER
let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.header__navbar');

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navbar.classList.toggle('open');
}

const nav = document.querySelector('.header__navbar');
window.addEventListener('scroll', function () {
    navbar.classList.toggle('active', window.scrollY > 0)
})






document.addEventListener('DOMContentLoaded', () => {
    const tituloObra = obtenerTituloDeURL();
    if (tituloObra) {
        obtenerDetallesDeObra(tituloObra);
    }

});



// FUNCION OBTENER TITULO DE LA URL
function obtenerTituloDeURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('titulo');
}



async function obtenerDetallesDeObra(titulo) {
    try {
        const response = await fetch(`/api/datosobras/${titulo}`);
        if (!response.ok) {
            throw new Error(`Error en la API: ${response.status}`);
        }
        const detallesObra = await response.json();
        mostrarDetalles(detallesObra);
    } catch (error) {
        console.error('Error al obtener detalles de la obra:', error);
    }
}





// MOSTRAR LOS DETALLES DE LAS OBRAS
function mostrarDetalles(detallesObra) {




    document.getElementById('obraTitulo').textContent = detallesObra.titulo;
    document.getElementById('obraDescripcion').textContent = detallesObra.descripcion;


    document.getElementById('obraAutores').textContent = detallesObra.autores;
    document.getElementById('obraValoracion').textContent = detallesObra.valoracion;
    document.getElementById('obraDirector').textContent = detallesObra.director;
    document.getElementById('obraDuracion').textContent = detallesObra.duracion;


    document.getElementById('obraReferencia').textContent = detallesObra.referencia;
    document.getElementById('obraSala').textContent = detallesObra.sala;






    const obraTitulo = detallesObra.titulo;
    const enlaceReservar = document.querySelector('.reservar-obras__button').parentNode;
    enlaceReservar.href = `reservas.html?obra=${encodeURIComponent(obraTitulo)}`;
}



