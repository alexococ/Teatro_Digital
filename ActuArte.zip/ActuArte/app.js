// app.js
const express = require('express'); // Importa el paquete express
const cors = require('cors'); // Importa el paquete cors
const app = express();
const PORT = 3000; // Puerto



app.use(express.json());
app.use(cors()); // Agrega el middleware cors



app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});


